from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()


class User(Base):
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), nullable=False)
    picture = Column(String(250), nullable=False)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'picture': self.picture

        }


class Category(Base):
    __tablename__ = 'category'
    cat_id = Column(Integer, primary_key=True)
    cat_name = Column(String(250), nullable=False)
    cat_owner_id = Column(Integer, ForeignKey('user.id'))
    user = relationship(User)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""

        return {
            'cat_name': self.cat_name,
            'cat_id': self.cat_id,
            'cat_owner_id': self.cat_owner_id
        }


class Item(Base):
    __tablename__ = 'item'

    item_name = Column(String(80), nullable=False)
    item_id = Column(Integer, primary_key=True)
    item_description = Column(String(250))
    cat_id = Column(Integer, ForeignKey('category.cat_id'))
    category = relationship(Category)
    item_owner_id = Column(Integer, ForeignKey('user.id'))
    user = relationship(User)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {
            'item_name': self.item_name,
            'item_description': self.item_description,
            'item_id': self.item_id,
            'cat_id': self.cat_id,
            'item_owner_id': self.item_owner_id
        }


engine = create_engine('sqlite:///catalog.db')

Base.metadata.create_all(engine)
