from flask import Flask, render_template, request, redirect, \
    jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database_setup import Base, Category, Item, User
from flask import session as login_session
import random
import string
from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import FlowExchangeError
import httplib2
import json
from flask import make_response
import requests

app = Flask(__name__)

# Connect to Database and create database session
engine = create_engine('sqlite:///catalog.db',
                       connect_args={'check_same_thread': False})
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()


# Create anti-forgery state token
@app.route('/login')
def showLogin():
    state = ''.join(random.choice(string.ascii_uppercase + string.digits)
                    for x in xrange(32))
    login_session['state'] = state
    return render_template('login.html', STATE=state)

# login via facebook
@app.route('/fbconnect', methods=['POST'])
def fbconnect():

    # Check for state mismatch
    if request.args.get('state') != login_session['state']:
        response = make_response(json.dumps('Invalid state parameter.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    # get acccess token from rquest
    access_token = request.data

    # get app id and secret from secrets file
    app_id = json.loads(open('fb_client_secrets.json', 'r').read())[
        'web']['app_id']
    app_secret = json.loads(
        open('fb_client_secrets.json', 'r').read())['web']['app_secret']

    # exchange token
    url = 'https://graph.facebook.com/oauth/access_token?grant_type=fb_' \
          'exchange_token&client_id=%s&client_secret=%s&fb_exchange_to' \
          'ken=%s' % (app_id, app_secret, access_token)
    h = httplib2.Http()
    result = h.request(url, 'GET')[1]

    # Use token to get user info
    token = result.split(',')[0].split(':')[1].replace('"', '')
    url = 'https://graph.facebook.com/v2.8/me?access_token=%s&fields=' \
          'name,id,email' % token
    h = httplib2.Http()
    result = h.request(url, 'GET')[1]

    # print "url sent for API access:%s"% url
    # print "API JSON result: %s" % result
    # set login values
    data = json.loads(result)
    login_session['provider'] = 'facebook'
    login_session['username'] = data["name"]
    login_session['email'] = data["email"]
    login_session['facebook_id'] = data["id"]

    # store token in login_session in for logout
    login_session['access_token'] = token

    # Get user picture
    url = 'https://graph.facebook.com/v2.8/me/picture?access_token=%s&' \
          'redirect=0&height=200&width=200' % token
    h = httplib2.Http()
    result = h.request(url, 'GET')[1]
    data = json.loads(result)

    login_session['picture'] = data["data"]["url"]

    # see if user exists
    user_id = getUserID(login_session['email'])
    if not user_id:
        user_id = createUser(login_session)
    login_session['user_id'] = user_id

    output = ''
    output += '<h1>Welcome, '
    output += login_session['username']
    output += '!</h1>'
    output += '<img src="'

    flash("Now logged in as %s" % login_session['username'])
    return output


# DISCONNECT - Revoke a current user's token and reset their login_session
@app.route('/fbdisconnect')
def fbdisconnect():
    facebook_id = login_session['facebook_id']
    # The access token must me included to successfully logout
    access_token = login_session['access_token']
    url = 'https://graph.facebook.com/%s/permissions?access_token' \
          '=%s' % (facebook_id, access_token)
    h = httplib2.Http()
    result = h.request(url, 'DELETE')[1]
    return "you have been logged out"


# User Helper Functions
def createUser(login_session):
    newUser = User(name=login_session['username'], email=login_session[
        'email'], picture=login_session['picture'])
    session.add(newUser)
    session.commit()
    user = session.query(User).filter_by(email=login_session['email']).one()
    return user.id


def getUserInfo(user_id):
    user = session.query(User).filter_by(id=user_id).one()
    return user


def getUserID(email):
    try:
        user = session.query(User).filter_by(email=email).one()
        return user.id
    except Exception:
        return None


# JSON APIs to view category and its list of items
@app.route('/category/<int:cat_id>/JSON')
def categoryJSON(cat_id):
    category = session.query(Category).filter_by(cat_id=cat_id).one()
    items = session.query(Item).filter_by(cat_id=cat_id).all()
    return jsonify(items=[i.serialize for i in items])


# JSON APIs to specific item's info
@app.route('/category/<int:cat_id>/item/<int:item_id>/JSON')
def itemJSON(cat_id, item_id):
    item = session.query(Item).filter_by(item_id=item_id).one()
    return jsonify(item=item.serialize)


# JSON APIs to view catalog and its list of catagories.
@app.route('/catalog/JSON')
def catalogJSON():
    catalog = session.query(Category).all()
    return jsonify(catalog=[r.serialize for r in catalog])


# Show catalog
@app.route('/')
@app.route('/catalog/')
def showCatalog():
    catalog = session.query(Category).order_by(asc(Category.cat_name))
    if 'username' not in login_session:
        return render_template('publicCatalog.html', catalog=catalog)
    else:
        return render_template('catalog.html', catalog=catalog)


# Create a new category
@app.route('/category/new/', methods=['GET', 'POST'])
def newCategory():
    if 'username' not in login_session:
        return redirect('/login')
    if request.method == 'POST':
        newCategory = Category(cat_name=request.form['cat_name'],
                               cat_owner_id=login_session['user_id'])
        session.add(newCategory)
        session.commit()
        flash('New Category %s Successfully Created' % newCategory.cat_name)
        return redirect(url_for('showCatalog'))
    else:
        return render_template('newCategory.html')


# Edit a Category
@app.route('/category/<int:cat_id>/edit/', methods=['GET', 'POST'])
def editCategory(cat_id):
    editedCategory = session.query(Category).filter_by(cat_id=cat_id).one()
    if 'username' not in login_session:
        return redirect('/login')
    if editedCategory.cat_owner_id != login_session['user_id']:
        return "<script>function myFunction() {alert('You are not authori" \
                "zed to edit this category. Please create your own categor" \
                "y in order to edit.');}</script><body onload='myFunction()'>"
    if request.method == 'POST':
        cancel = request.form.get('cancel')
        if not cancel:
            if request.form['cat_name']:
                editedCategory.cat_name = request.form['cat_name']
                session.add(editedCategory)
                session.commit()
                flash('Category Successfully Edited %s' %
                      editedCategory.cat_name)
        return redirect(url_for('showCategory', cat_id=cat_id))
    else:
        return render_template('editCategory.html', category=editedCategory)


# Delete a category
@app.route('/category/<int:cat_id>/delete/', methods=['GET', 'POST'])
def deleteCategory(cat_id):
    categoryToDelete = session.query(Category).filter_by(cat_id=cat_id).one()
    if 'username' not in login_session:
        return redirect('/login')
    if categoryToDelete.cat_owner_id != login_session['user_id']:
        return "<script>function myFunction() {alert('You are not authorize" \
                "d to delete this category. Please create your own category" \
                "in order to delete.');}</script><body onload='myFunction()'>"
    if request.method == 'POST':
        cancel = request.form.get('cancel')
        if not cancel:
            session.delete(categoryToDelete)
            session.commit()
            flash('%s Successfully Deleted' % categoryToDelete.cat_name)
        return redirect(url_for('showCatalog', cat_id=cat_id))
    else:
        return render_template('deleteCategory.html',
                               category=categoryToDelete)


# Show a category items
@app.route('/category/<int:cat_id>/')
def showCategory(cat_id):
    category = session.query(Category).filter_by(cat_id=cat_id).one()
    creator = getUserInfo(category.cat_owner_id)
    items = session.query(Item).filter_by(cat_id=cat_id).all()
    if 'username' not in login_session or \
            creator.id != login_session['user_id']:
        return render_template('publicShowCategory.html',
                               items=items, category=category, creator=creator)
    else:
        return render_template('showCategory.html',
                               items=items, category=category, creator=creator)


# Create a new item
@app.route('/category/<int:cat_id>/item/new/', methods=['GET', 'POST'])
def newItem(cat_id):
    if 'username' not in login_session:
        return redirect('/login')
    category = session.query(Category).filter_by(cat_id=cat_id).one()
    categories = session.query(Category).order_by(asc(Category.cat_name))
    if login_session['user_id'] != category.cat_owner_id:
        return "<script>function myFunction() {alert('You are not authorize" \
                "d to add items to this category. Please create your own ca" \
                "tegory.');}</script><body onload='myFunction()'>"
    if request.method == 'POST':
        newItem = Item(item_name=request.form['item_name'],
                       item_description=request.form['item_description'],
                       cat_id=request.form['category'],
                       item_owner_id=login_session['user_id'])
        session.add(newItem)
        session.commit()
        flash('New %s Item Successfully Created' % (newItem.item_name))
        return redirect(url_for('showCategory', cat_id=cat_id))
    else:
        return render_template('newItem.html', cat_name=category.cat_name,
                               categories=categories)


# Edit a item
@app.route('/category/<int:cat_id>/item/<int:item_id>/edit',
           methods=['GET', 'POST'])
def editItem(cat_id, item_id):
    if 'username' not in login_session:
        return redirect('/login')
    editedItem = session.query(Item).filter_by(cat_id=cat_id,
                                               item_id=item_id).one()
    categories = session.query(Category).order_by(asc(Category.cat_name))
    if login_session['user_id'] != editedItem.item_owner_id:
        return "<script>function myFunction() {alert('You are not authorize" \
              "d to edit items to this category. Please create your own cat" \
              "egory.');}</script><body onload='myFunction()'>"
    if request.method == 'POST':
        if request.form['item_name']:
            editedItem.item_name = request.form['item_name']
        if request.form['item_description']:
            editedItem.item_description = request.form['item_description']
        if request.form['category']:
            editedItem.cat_id = request.form['category']
        session.add(editedItem)
        session.commit()
        flash('Item Successfully Edited')
        return redirect(url_for('showCategory', cat_id=cat_id))
    else:
        return render_template('editItem.html', categories=categories,
                               item=editedItem)


# Delete a item
@app.route('/category/<int:cat_id>/item/<int:item_id>/delete',
           methods=['GET', 'POST'])
def deleteItem(cat_id, item_id):
    if 'username' not in login_session:
        return redirect('/login')
    itemToDelete = session.query(Item).filter_by(cat_id=cat_id,
                                                 item_id=item_id).one()
    if login_session['user_id'] != itemToDelete.item_owner_id:
        return "<script>function myFunction() {alert('You are not authorize" \
                "d to delete items to this category. Please create your own" \
                " category.');}</script><body onload='myFunction()'>"
    if request.method == 'POST':
        cancel = request.form.get('cancel')
        # print "cancel: %s" % cancel
        if not cancel:
            session.delete(itemToDelete)
            session.commit()
            flash('Item Successfully Deleted')
        return redirect(url_for('showCategory', cat_id=cat_id))
    else:
        return render_template('deleteItem.html', item=itemToDelete)


# Disconnect based on provider
@app.route('/disconnect')
def disconnect():
    if 'provider' in login_session:
        if login_session['provider'] == 'facebook':
            fbdisconnect()
            del login_session['facebook_id']
        del login_session['username']
        del login_session['email']
        del login_session['picture']
        del login_session['user_id']
        del login_session['provider']
        flash("You have successfully been logged out.")
        return redirect(url_for('showCatalog'))
    else:
        flash("You were not logged in")
        return redirect(url_for('showCatalog'))


if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.debug = True
    app.run(host='0.0.0.0', port=5000)
