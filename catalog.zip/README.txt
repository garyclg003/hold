Item Catalog Project

This project builds a web app that provides a list of items within a variety of categories as well as provides a user authentication system. Registered users will have the ability to post, edit and delete their own items. The interface is self-explanatory and user friendly. 

The application consists of 2 python files described below.
1) application.py This is the main application server. 
2) database_setup.py This is the python file that will generate the database. 

The application consists of 13 HTML files that functionally control and display the user interface and they can be found in the catalog/template directory. 

The application utilizes one CSS file and can be found in the static directory. The static directory also houses 3 images. 

The application utilizes a sqlalchemy relational database and will create a catalog.db in the catalog directory. 

To application server can be executed by running python application.py from the catalog directory.

The application runs on the users localhost and can be accessed via http://localhost:5000/. 

User Access is controlled by a user�s Facebook login profile and the app_id and app_secret will be stored in the catalog directory. Chang this values will breaks the applications login capabilities. 

If the user does not have a Facebook account or does not login they will be able to use the read features of the application. 

User can run this application via a vagrant virtual machine. The vagrant VM can be downloaded at https://github.com/udacity/fullstack-nanodegree-vm and contains a README file for instructions on how to get it up and running.
